<?php
/**
 * Plugin Name: Wordpress Roundabout Slideshow Plugin
 * Plugin URI: http://www.jmcdesignstudios.com/roundabout_slideshow
 * Description: A plugin that provides a roundabout slideshow (JQuery Roundabout)
 * Author: Jared Clapp
 * Version: 1.0
 * Author URI: http://jmcdesignstudios.com
 */

/*
Plugin Name: Advanced Custom Fields
Plugin URI: http://www.advancedcustomfields.com/
Description: Fully customise WordPress edit screens with powerful fields. Boasting a professional interface and a powerfull API, it�s a must have for any web developer working with WordPress. Field types include: Wysiwyg, text, textarea, image, file, select, checkbox, page link, post object, date picker, color picker, repeater, flexible content, gallery and more!
Version: 4.1.1
Author: Elliot Condon
Author URI: http://www.elliotcondon.com/
License: GPL
Copyright: Elliot Condon
*/



require_once('includes/roundabout_slideshow_plugin.php');

?>