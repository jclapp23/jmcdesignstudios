//self executing function to avoid conflicts
(function($) {
	// this behaves as if within document.ready
	$(document).ready(function() {
	
 
		$('#slideshow').roundabout({
		btnNext: ".next",
		btnPrev: ".prev",
		duration: 1000,
		autoplay: true,
		autoplayDuration: 5000
		});

	  }); //end doc rdy

//});

}(jQuery))