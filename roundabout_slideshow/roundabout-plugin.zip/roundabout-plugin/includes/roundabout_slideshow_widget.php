<?php

class RoundaboutSlideshowWidget extends WP_Widget {
        
    public function RoundaboutSlideshowWidget() {
        parent::WP_Widget(false, $name = 'Roundabout Slideshow', $widget_options = array('description' => 'Roundabout Slideshow'));
        
    } 
    
    /**
     * Gets slides puts them into an array with their post id
     *
     * @return array An array containing slide urls and post ids.
     */
    private function get_slides() {
        
        $posts = get_posts(array('numberposts' => -1, 'post_type' => 'slide'));
        
        //var_dump($posts);
        
        $slides = array();
        
        foreach($posts as $post) 
        {
            if (has_post_thumbnail( $post->ID ))
            { 
				$slide_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), array(390,305) );
           	 	$title = $post->post_title;
              	array_push($slides, array('post_id' => $post->ID, 'title' => $title,'slide_url'=> $slide_url[0]));
          	}
        }
        return $slides;
        
        //var_dump($slides);
    }
   
    /**
     * Builds the calendar HTML to be output in the widget
     *
     * @param string $year 
     * @param string $month 
     * @return string The HTML for the calendar.
     */
    private function build_slideshow() {
        
        $output = '<!-- Roundabout Slideshow -->';
        $output .= '<ul id="slideshow">';
        
        $slides = $this->get_slides();

        foreach ($slides as $slide) {
            
            $output .= '<li><span><img src='. $slide['slide_url'].' alt='.$slide['title'].'></a></span></li>';
       
            }
        $output .= '</ul>';

		$output .= '<!-- End Roundabout Slideshow -->';

        return $output;
    }

    public function form($instance) {
        
        $title = strip_tags($instance['title']);

        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title:</label> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></p>
        
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        
        return $instance;
    }

    public function widget($args, $instance) {      
        /*extract($args);
        
        $title = apply_filters('widget_title', $instance['title']);
        
        echo $before_widget;
        
        if ($title) {
            echo $before_title . $title . $after_title;
        }
        */
        echo $this->build_slideshow();
          
        //echo $after_widget;
    }   

}

add_action('widgets_init', create_function('', 'return register_widget("RoundaboutSlideshowWidget");'));

?>