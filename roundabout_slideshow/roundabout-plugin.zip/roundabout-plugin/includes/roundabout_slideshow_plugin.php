<?php

require_once('roundabout_slideshow_config.php');
require_once('roundabout_slideshow_functions.php');
require_once('roundabout_slideshow_widget.php');

/**
 * The Roundabout Slideshow Wordpress Plugin class.
 * 
 * @author jclapp
 */
class RoundaboutSlideshowPlugin {

    public function __construct() {
        
        /* Register the custom-post types */
        add_action('init', array('RoundaboutSlideshowPlugin', 'register_post_types'));
        
        /* Register the custom-post colums and column data for list page */
        add_filter("manage_edit-slide_columns", array('RoundaboutSlideshowPlugin', 'slide_edit_columns')); 
        
        /* Register the custom-post save action */
        add_action('save_post', array('RoundaboutSlideshowPlugin', 'event_save_postdata'));
        
        
        // add admin scripts
        //add_action('admin_enqueue_scripts', array('RoundaboutSlideshowPlugin', 'admin_scripts'));

        // add calendar widget scripts
        add_action('wp_enqueue_scripts', array('RoundaboutSlideshowPlugin', 'widget_scripts'));
        
        /* Register the deactivate function */
        register_deactivation_hook(WP_PLUGIN_URL.'/roundabout-plugin/roundabout_slideshow.php', array('RoundaboutSlideshowPlugin', 'roundaboutslideshow_deactivate'));
    }
    
   /* public function admin_scripts() {
       wp_register_style('jquery-ui-css', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.11/themes/ui-lightness/jquery-ui.css');
        
       wp_enqueue_style('jquery-ui-css');
            
       wp_register_script('event-calendar-admin-js', WP_PLUGIN_URL.'/wordpress-eventcalendar/js/admin.js', array('jquery-ui-core', 'jquery-ui-datepicker'));
        
       wp_enqueue_script('event-calendar-admin-js');
    }
    */
       
    public function widget_scripts() {
        wp_register_style('custom-style', WP_PLUGIN_URL.'/roundabout-plugin/css/style.css');
        
        wp_enqueue_style('custom-style');
        
        wp_register_script('roundabout-js', WP_PLUGIN_URL.'/roundabout-plugin/js/jquery.roundabout.min.js', array('jquery'));
        
        wp_enqueue_script('roundabout-js');
        
         wp_register_script('roundabout-settings-js', WP_PLUGIN_URL.'/roundabout-plugin/js/roundabout_settings.js', array('roundabout-js'));
        
        wp_enqueue_script('roundabout-settings-js');
        
        //wp_localize_script('event-calendar-js', 'EventCalendarAjax', array('ajaxurl' => admin_url('admin-ajax.php')));
    }

    /* Registers the custom post types with WordPress core */
    public function register_post_types() {
        
        //SLDIES
		$labels = array(
			'name' => _x( 'Slides', 'slide' ),
			'singular_name' => _x( 'Slide', 'slide' ),
			'add_new' => _x( 'Add New', 'slide' ),
			'add_new_item' => _x( 'Add New Slide', 'slide' ),
			'edit_item' => _x( 'Edit Slide', 'slide' ),
			'new_item' => _x( 'New Slide', 'slide' ),
			'view_item' => _x( 'View Slide', 'slide' ),
			'search_items' => _x( 'Search Slides', 'slide' ),
			'not_found' => _x( 'No slides found', 'slide' ),
			'not_found_in_trash' => _x( 'No slides found in Trash', 'slide' ),
			'parent_item_colon' => _x( 'Parent Slide:', 'slide' ),
			'menu_name' => _x( 'Slides', 'slide' ),
		);
		$args = array(
		    'labels' => $labels,
            'public'  => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'menu_position' => 5,
            'rewrite' => array('slug'=>'slide'), 
            'supports' => array('title','thumbnail')
		);
        
        register_post_type('slide',$args);
        
        /* Flush rewrite rules */
        if (ROUNDABOUTSLIDESHOW_FLUSH_URLS) {
            flush_rewrite_rules();
        }
        
        /* Add javascript to plugin pages */
        //wp_enqueue_script('jquery-ui');
        //wp_enqueue_script('EventCalendarJs');
        
        /* Add css to plugin pages */
        //wp_enqueue_style('jquery-ui-css');
        //wp_enqueue_style('EventCalendarCSS');
    
    }
    
     /* Updates or adds meta data on save */
    public function event_save_postdata($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
    }
     
    /* Adds event columns to list page */
    public function slide_edit_columns($columns) {
        $columns = array(  
            'cb' => '<input type="checkbox" />',  
            'title' => 'Title'
        );

        return $columns; 
    }
    
    // clean up on deactivate
    public function roundaboutslideshow_deactivate() {
        // delete posts
        $posts = get_posts(array('numberposts' => -1, 'post_type' => 'slide'));
        
        foreach($posts as $post) {
            wp_delete_post($post->ID, true);
        }
    }
}

$RoundaboutSlideshowPlugin = new RoundaboutSlideshowPlugin();
    
?>