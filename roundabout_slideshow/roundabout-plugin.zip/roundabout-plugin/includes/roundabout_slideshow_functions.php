<?php

/**
 * Outputs the specified debugging message if ROUNDABOUTSLIDESHOW_DEBUG is true.
 * 
 * @param string $message The debugging message.
 */
function roundaboutslideshow_debug($message='') {
    if (ROUNDABOUTSLIDESHOW_DEBUG) {
        $log = fopen(ROUNDABOUTSLIDESHOW_DEBUG_LOG, 'a');
        
        if (is_resource($log)) {
            fwrite($log, $message . "\r\n");
            fclose($log);
        } else {
            error_log('DEBUG: ' . $message);
        }
    }
}

?>