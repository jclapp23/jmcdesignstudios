-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.jmcdesignstudios.com
-- Generation Time: Apr 22, 2013 at 02:23 PM
-- Server version: 5.1.56
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `etodoit`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `todo_id` int(10) NOT NULL,
  `category` text NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `todo_id`, `category`) VALUES
(1, 114, 'grocery'),
(2, 114, 'groceries'),
(3, 115, 'testing'),
(4, 116, 'school'),
(5, 116, 'notlistening'),
(6, 117, 'awesome'),
(7, 118, 'payments'),
(8, 119, 'payments'),
(9, 120, 'unemployment'),
(10, 121, 'unemployment'),
(11, 122, 'groceries'),
(12, 123, 'payments'),
(13, 124, 'groceries'),
(14, 127, 'payments'),
(15, 127, 'payments'),
(16, 128, 'have'),
(17, 139, 'payments'),
(18, 140, 'weddings'),
(19, 145, 'groceries'),
(20, 146, 'work'),
(21, 150, 'taskappfeatures'),
(22, 151, 'taskappfeatures'),
(23, 152, 'payments'),
(24, 153, 'groceries'),
(25, 154, 'payments'),
(26, 155, 'groceries'),
(27, 156, 'groceries'),
(28, 157, 'groceries'),
(29, 158, 'groceries'),
(30, 159, 'payments'),
(31, 160, 'groceries'),
(32, 161, 'groceries'),
(33, 170, 'payments'),
(34, 172, 'groceries'),
(35, 176, 'school'),
(36, 178, 'school'),
(37, 181, 'groceries');

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE IF NOT EXISTS `todos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `todo` text NOT NULL,
  `uid` int(10) NOT NULL,
  `time_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `calendar_time` datetime NOT NULL,
  `close_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(10) NOT NULL DEFAULT 'open',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=210 ;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `todo`, `uid`, `time_added`, `calendar_time`, `close_time`, `status`) VALUES
(190, 'Buy bow tie and crazy colored pants, shoes', 3, '2013-03-27 10:25:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(206, 'Throw away coffee cups hot and iced , iced brewing container ', 3, '2013-04-07 17:45:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(58, 'rebuild kee kar lau', 16, '2013-02-17 17:30:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(59, 'Remind Crapp to send valentines card to leann Hopkins sons, grandfathers, daughter ', 12, '2013-02-17 17:35:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(61, 'get stuff at store', 9, '2013-02-17 17:45:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(209, 'pay rent ', 3, '2013-04-16 00:30:05', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(139, '#payments pay bri for maxwell beach house', 3, '2013-03-08 08:35:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(67, 'Cash checks ', 4, '2013-02-17 21:35:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(180, 'White fabric marker, Michaels', 3, '2013-03-25 21:50:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(72, 'CVS Amazon gift card', 6, '2013-02-18 06:15:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(70, 'Sponges for kitchen', 6, '2013-02-18 06:10:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(71, 'Dog food', 6, '2013-02-18 06:10:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(73, 'Return Soap to Whole Foods', 6, '2013-02-18 06:15:10', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(74, 'Case of water Walmart', 6, '2013-02-18 06:15:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(125, '', 30, '2013-03-06 04:15:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(126, 'Red''s Army Party Sunday with JC', 13, '2013-03-06 06:10:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(77, 'Go on tour', 7, '2013-02-18 07:45:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(95, 'Sign up for local fast pass discount ', 3, '2013-02-22 05:30:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(205, 'Collar ties for white shirt Marshall''s ', 3, '2013-04-05 17:35:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(207, 'Flow trol before tues ', 3, '2013-04-07 17:45:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(175, 'Fast past velcro', 3, '2013-03-24 14:20:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(208, 'Flowtrol at lunch ', 3, '2013-04-08 18:55:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(148, 'Switch domain to jmcdesign studios ', 3, '2013-03-09 14:15:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(197, 'Bleach baseball t and polo ', 3, '2013-03-28 11:35:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(145, 'pick up eggs #groceries ', 31, '2013-03-09 09:15:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(146, 'Shushed has #work', 31, '2013-03-09 09:20:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(195, 'create github site, include on resume', 3, '2013-03-28 09:05:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open'),
(203, 'Pay Somerville ticket ', 3, '2013-04-02 17:05:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'open');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `email_primary` varchar(50) NOT NULL,
  `email_seconday` varchar(50) NOT NULL,
  `email_other` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `email_primary` (`email_primary`,`email_seconday`,`email_other`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `email_primary`, `email_seconday`, `email_other`, `password`) VALUES
(4, 'johnd83@gmail.com', '', '', 'test'),
(3, 'jclapp23@gmail.com', '', '', '722c722c'),
(5, 'magulino_99@yahoo.com', '', '', 'test'),
(6, 'dclapp2400@gmail.com', '', '', 'celtics1'),
(7, 'jclapp2300@yahoo.com', '', '', 'test'),
(8, 'clapp.d@gmail.com', '', '', 'test'),
(9, 'smithrobertt@gmail.com', '', '', 'test'),
(25, 'murphy.melissa7@gmail.com', '', '', 'Garnett731'),
(11, 'gmccarthy45@gmail.com', '', '', 'test'),
(12, 'andrewmkeenan@gmail.com', '', '', 'test'),
(13, 'gordyryan@gmail.com', '', '', 'test'),
(14, 'leomacdonald3@gmail.com', '', '', 'test'),
(15, 'Ryan.M.Maxwell@gmail.com', '', '', 'test'),
(16, 'tim.johnstn@gmail.com', '', '', 'test'),
(17, 'cwparker16@gmail.com', '', '', 'test'),
(26, 'mikehandley11@gmail.com', '', '', 'terre11'),
(23, 'test@gmail.com', '', '', '34324323'),
(27, 'testing@gmail.com', '', '', 'qwerty'),
(28, 'test4@gmail.com', '', '', 'test'),
(29, '', '', '', ''),
(30, 'abbybmarsh@gmail.com', '', '', 'todolist'),
(31, 'jprince8683@yahoo.com', '', '', 'prince4683');
