$(document).ready(function() {
    
    $("#register").validate();
  

	
  
});