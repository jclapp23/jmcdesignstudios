<?php

require_once 'functions.php';

log_out_user();

?>

<center>

<div class='page-header'>
  <h4>Log Out</h4>
</div>

  <p>You have logged out successfully.</p>
  
  <a href='index.php' title='Go back to the home screen for our task list web application.'>Go to home page.</a>
  
  
 </center>