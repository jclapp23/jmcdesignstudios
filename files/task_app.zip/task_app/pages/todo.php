<?php
  
  date_default_timezone_set('America/New_York'); 
  
  echo "<center>";
  echo "<div class='page-header'>";
  echo "<h4>To-do List</h4>";
  echo "<a href='#myModal' data-toggle='modal' title='An explanation of our free mobile-friendly email powered task, todo, organizational application.'>How's this work?</a><br/>";
  
  if( $user_id = get_user_id() )
  {
    $user = get_user($_SESSION['user_id']);
    $user = $user->email_primary;
    echo "<small>Welcome back <em>$user</em> &nbsp;</small>"; 
    echo "<a class='btn' href='?page=logout'>Log Out</a>";
  };
  echo "</div>";

  show_user_status();
 
  if( $user_id = get_user_id() )
  {
 
   echo"<div id='filter_holder'>
 		<select id='category_filter'>
			<option>select a category</option>
			<option>groceries</option>
			<option>payments</option>
			<option>work</option>
 		</select>
 		<div class='clear'></div>
 </div>";
 $result = getTodos(); 
  
 while ($row = mysql_fetch_object($result)){
      echo "<div class='well well-small'>";
      echo "<p class='text-success'> {$row->todo}</p>";
      $time = date("F j, Y, g:i a", strtotime($row->time_added)); 
      
	  echo "<p><small>$time <a class='btn btn-danger' href='pages/delete-todo.php?id={$row->id}'>Remove</a></small></p>";
      
	  $id = $row->id;
	  
	  $categories = getCategories($id);
	  
	  if($categories){
		   echo "<div class='category_holder'>";
		  }
	  
	  while ($row2 = mysql_fetch_object($categories)){
				$category = $row2->category;
		  		echo "<div class='category_box'>{$category}</div>";		
		  }
	  
	    
	  if($categories){
		   echo "<div class='clear'></div>";
		   echo "</div>";
		  }
	  
	  echo "</div>";

	}; 
	
};	
echo "</center>";
  
  

 

 
?>
